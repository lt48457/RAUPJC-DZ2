﻿using Interfaces;
using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zadatak3;

namespace Repositories
{
    /// <summary >
    /// Class  that  encapsulates  all  the  logic  for  accessing  TodoTtems.
    ///  </summary >
    public class TodoRepository : ITodoRepository
    {
        /// <summary >
        /// Repository  does  not  fetch  todoItems  from  the  actual  database ,
        /// it uses in  memory  storage  for  this  excersise.
        /// </summary >
        private readonly IGenericList<TodoItem> _inMemoryTodoDatabase;
        public TodoRepository(IGenericList<TodoItem> initialDbState = null)
        {
            if (initialDbState != null)
            {
                _inMemoryTodoDatabase = initialDbState;
            }
            else
            {
                _inMemoryTodoDatabase = new GenericList<TodoItem>();
            }
            //  Shorter  way to  write  this in C# using ??  operator:
            //  _inMemoryTodoDatabase = initialDbState  ?? new List <TodoItem >();
            // x ?? y -> if x is not null , expression  returns x. Else y.
        }

        public void Add(TodoItem todoItem)
        {
                _inMemoryTodoDatabase.Add(todoItem);           

        }

        public TodoItem Get(Guid todoId)
        {
            
            return _inMemoryTodoDatabase.Where(x => x.Id.Equals(todoId)).First();

        }

        public List<TodoItem> GetActive()
        {
            return _inMemoryTodoDatabase.Where(x => x.IsCompleted == false).ToList();
        }

        public List<TodoItem> GetAll()
        {
            return _inMemoryTodoDatabase.OrderBy(x => x.DateCreated).ToList();

        }

        public List<TodoItem> GetCompleted()
        {
            return _inMemoryTodoDatabase.Where(x => x.IsCompleted == true).ToList();

        }

        public List<TodoItem> GetFiltered(Func<TodoItem, bool> filterFunction)
        {
            return _inMemoryTodoDatabase.Where(filterFunction).ToList();

        }

        public bool MarkAsCompleted(Guid todoId)
        {
            TodoItem _a = Get(todoId);
            if (_a == null) return false;
            _a.MarkAsCompleted();
            Update(_a);
            return true;

        }

        public bool Remove(Guid todoId)
        {
            return _inMemoryTodoDatabase.Remove(Get(todoId));

        }

        public void Update(TodoItem todoItem)
        {
            Remove(todoItem.Id);
            Add(todoItem);

        }
    }
    //  implement  ITodoRepository
}