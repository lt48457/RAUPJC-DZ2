﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZADATAK78
{
    class Program
    {
        static void Main(string[] args)
        {
            // Main method is the only method that
            // can ’t be marked with async .
            // What we are doing here is just a way for us to simulate
            // async - friendly environment you usually have with
            // other .NET application types ( like web apps , win apps etc .)
            // Ignore main method , you can just focus onLetsSayUserClickedAButtonOnGuiMethod() as a
            // first method in call hierarchy .
            var t = Task.Run(() => LetsSayUserClickedAButtonOnGuiMethod());
            Console.Read();
        }
        private static async void LetsSayUserClickedAButtonOnGuiMethod()
        {
            var result = await GetTheMagicNumber();
            Console.WriteLine(result);
        }
        private static async Task<int> GetTheMagicNumber()
        {
            return await IKnowIGuyWhoKnowsAGuy();
        }
        private static async Task<int> IKnowIGuyWhoKnowsAGuy()
        {
            int x = await IKnowWhoKnowsThis(10);
            int y = await IKnowWhoKnowsThis(5);
            return x + y;
        }
        private static async Task<int> IKnowWhoKnowsThis(int n)
        {
            await FactorialDigitSum(n);
            return FactorialDigitSum(n).Result;
        }
        private static Task<int> FactorialDigitSum(int n)
        {
            Task<int> t1 = Task.Run(() => MyMethod(n));
            return t1;
        }
        private static int MyMethod(int n)
        {
            int a = 1;
            for (int i = 2; i <= n; i++)
            {
                a *= i;
            }

            int s = 0;
            while (a >= 1)
            {
                s += a-(a / 10)*10;
                a = a / 10;

            }
                return s;

        }

    }
}
