﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZADATAK345
{
    public class Student
    {
        public string Name { get; set; }
        public string Jmbag { get; set; }
        public Gender Gender { get; set; }
        public Student(string name, string jmbag, Gender gender)
        {
            Name = name;
            Jmbag = jmbag;
            Gender = gender;
        }

        
        public override int GetHashCode()
        {
            int hashName = Name == null ? 0 : Name.GetHashCode();
            int hashJmbag = Jmbag == null ? 0 : Jmbag.GetHashCode();
            int hash = hashName ^ hashJmbag;
            return hash;
        }

        public override bool Equals(object _obj)
        {
     
            if (this == _obj) return true;

            if (!(_obj.GetType()==typeof(Student))) return false; 

            Student _student = (Student)_obj;

            return Jmbag.Equals(_student.Jmbag);
        }




    }
}
