﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZADATAK345
{
    class Program
    {
        static void Main(string[] args)
        {
            //Zadatak 3
            Console.WriteLine("Zadatak 3");
            int[] _integers = new[] { 1, 2, 2, 2, 3, 3, 4, 5 };
            int[] _distIntegers = _integers.Distinct().ToArray();
            string[] _strings = _distIntegers.Select(x => "Broj " + x.ToString() + " ponavlja se " + _integers.Count(a => x == a).ToString() + " puta").ToArray();
                       
            for (int i = 0; i < _strings.Length; i++)
            {
                Console.WriteLine(_strings[i]);
            }
            Console.WriteLine();

            //Zadatak 4
            Console.WriteLine("Zadatak 4");
            Example1();
            Example2();
            //Console.ReadLine();
            Console.WriteLine();

            //Zadatak 5
            Console.WriteLine("Zadatak 5");
            University[] universities = GetAllCroatianUniversities();
            Student[] allCroatianStudents = null;
            Student[] temp1 = universities.SelectMany(x => x.Students).ToArray();
            allCroatianStudents = temp1.Distinct().ToArray();            
            Student[] temp2 = universities.Where(u => u.Students.Count(x => x.Gender.Equals(Gender.Female)) == 0).SelectMany(z=>z.Students).ToArray();
            Student[] croatianStudentsOnMultipleUniversities = allCroatianStudents.Where(s=>temp1.Count(a => s.Equals(a)) >1).ToArray();
            Student[] studentsOnMaleOnlyUniversities = allCroatianStudents.Where(s => temp2.Contains(s)).ToArray();

            System.Console.WriteLine("Svi Studenti");
            foreach (Student element in allCroatianStudents)
            {
                System.Console.WriteLine(element.Name);
            }
            System.Console.WriteLine();
            System.Console.WriteLine("Studenti na vise fakulteta");
            foreach (Student element in croatianStudentsOnMultipleUniversities)
            {
                System.Console.WriteLine(element.Name);
            }
            System.Console.WriteLine();
            System.Console.WriteLine("Studenti na muskim fakultetima");
            foreach (Student element in studentsOnMaleOnlyUniversities)
            {
                System.Console.WriteLine(element.Name);
            }
            System.Console.ReadLine();
        }

        private static University[] GetAllCroatianUniversities()
        {
            University[] uni = new University[3];
            Student[] t1 = new Student[3];
            Student[] t2 = new Student[3];
            Student[] t3 = new Student[3];
            t1[0] = new Student("Lucija", "123456", Gender.Female);
            t1[1] = new Student("Mare", "546789", Gender.Female);
            t1[2] = new Student("Ivan", "125478", Gender.Male);
            t2[0] = new Student("Ante", "123498", Gender.Male);
            t2[1] = new Student("Luka", "528789", Gender.Male);
            t2[2] = new Student("Ivan", "125478", Gender.Male);
            t3[0] = new Student("Sandra", "127256", Gender.Female);
            t3[1] = new Student("Mare", "546789", Gender.Female);
            t3[2] = new Student("Nikola", "128478", Gender.Male);
            uni[0]=new University("FER",t1);
            uni[1] = new University("PMF", t2);
            uni[2] = new University("FSB",t3);
            return uni;
        }

        static void Example1()
        {
            var list = new List<Student>()
            {
                new Student (" Ivan "," 001234567 ", Gender.Male)
            };
            var ivan = new Student(" Ivan ", " 001234567 ", Gender.Male);
            // false :(
            //true :)
            bool anyIvanExists = list.Any(s => s.Equals(ivan));
            Console.WriteLine(anyIvanExists);
        }

        static void Example2()
        {
            var list = new List<Student>()
            {
                new Student (" Ivan ", " 001234567 ", Gender.Male),
                new Student (" Ivan ", " 001234567 ", Gender.Male)
            };
            // 2 :(
            //1 :)
            var distinctStudents = list.Distinct().Count();
            Console.WriteLine(distinctStudents);
        }
    }
}
